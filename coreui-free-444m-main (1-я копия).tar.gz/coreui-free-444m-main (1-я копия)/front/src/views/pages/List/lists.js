import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';
// users from API.
const [users, setUsers] = useState([]);
useEffect(() => {
  fetchData();
}, []);






// async function
const fetchData = async () => {
  await fetch('http://localhost:3001/api/users')
    .then(response => response.json())
    .then(data => setUsers(data))
    .catch((error) => {
      console.log("ERROR:" + error);
    })
}

const [query, setQuery] = useState("");

  const search = (data) => {
    return data.filter(
      item => item.name.toLowerCase().includes(query));
  }
  <div className="App">
    <h1>PRUEBA DE NIVEL</h1>

    <select className='select' onChange={changeSelectedFilter}>
      <option value="">All</option>
      <option value="name">Name</option>
      <option value="username">Username</option>
      <option value="email">Email</option>
      <option value="phone">Phone</option>
    </select>

    <input type="text"
      placeholder='Search...'
      className='search'
      onChange={e => setQuery(e.target.value.toLowerCase())}
    />
    <UserTable data={search(users)} filter={selectedFilter} />

  </div>


export default Lists;